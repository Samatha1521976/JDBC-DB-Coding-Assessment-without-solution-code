package com.asde.dbconnect;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.asde.dbconnect.dao.EmployeeDAO;
import com.asde.dbconnect.entities.Employee;



/**
 * Unit test for simple App.
 */
public class AppTest 
   
{
    
    
    
    
    
    @Test
	public void searchById() throws SQLException 
	
	
	{
		EmployeeDAO empdaoimpl = new EmployeeDAO(); // Employee e1=new
		
		  Employee e1=new Employee();
		  e1.setEmployeeId(1);
		  List l=empdaoimpl.searchEmployee(e1);
		 
		  
		  String expected=l.toString();
		 

		  String result="[1, xxx, yyy, xxy, Senior Associate, Software Engineer]";
		  
		  
		  
		 
		assertEquals(expected,result);
		  
		
	
	
	}

	
	
	@Test
	public void searchByDesignation() throws SQLException 
	
	
	{

		  EmployeeDAO empdaoimpl = new EmployeeDAO();
		  
		 
		  
		  List l = empdaoimpl.searchEmployeeByDesignation("Senior Associate");
		
	String expected=l.toString();
	String result="[1, xxx, yyy, xxy, Senior Associate, 3, bcd, tys, yuo, Senior Associate]";
	assertEquals(expected,result);
	
	}
}
