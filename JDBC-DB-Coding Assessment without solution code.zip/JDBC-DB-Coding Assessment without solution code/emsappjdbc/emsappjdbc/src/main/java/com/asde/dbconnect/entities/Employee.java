package com.asde.dbconnect.entities;


import java.time.LocalDate;
public class Employee 
{
public int employeeId;
public String firstName;
public String lastName;
public String surName;
public LocalDate joiningDate;
public LocalDate birthDate;
public String qualification;
public String address;
public int contactNo;
public Designation designation;


public  Employee ()
{
	
	
}
public int getEmployeeId() {
}
public void setEmployeeId(int employeeId) {
}
public String getFirstName() {
}
public void setFirstName(String firstName) {
}
public String getLastName() {
}
public void setLastName(String lastName) {
}
public String getSurName() {
}
public void setSurName(String surName) {
}
public LocalDate getJoiningDate() {
}
public void setJoiningDate(LocalDate joiningDate) {
}
public LocalDate getBirthDate() {
}
public void setBirthDate(LocalDate birthDate) {
}
public String getQualification() {
}
public void setQualification(String qualification) {
}
public String getAddress() {
}
public void setAddress(String address) {
}
public int getContactNo() {
}
public void setContactNo(int contactNo) {
}
public Designation getDesignation() {

}
public void setDesignation(Designation designation) {

}
public Role getRole() {

}
public void setRole(Role role) {
	
}
public Role role;
public Employee(int employeeId, String firstName, String lastName, String surName, LocalDate joiningDate,
		LocalDate birthDate, String qualification, String address, int contactNo, Designation designation, Role role) {
	
}
@Override
public String toString() {
	
}



}




/*public class Employee 
{
public int employeeId;
public String firstName;
String lastName;
String surName;
LocalDate joiningDate;
LocalDate birthDate;
String qualification;
String address;
int contactNo;
String designation;
String role;
public Employee(int employeeId, String firstName, String lastName, String surName, LocalDate joiningDate, LocalDate birthDate,
		String qualification, String address, int contactNo, String designation, String role) {
	super();
	this.employeeId = employeeId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.surName = surName;
	this.joiningDate = joiningDate;
	this.birthDate = birthDate;
	this.qualification = qualification;
	this.address = address;
	this.contactNo = contactNo;
	this.designation = designation;
	this.role = role;
}



public Employee()
{
	
	
}



@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName + ", surName="
			+ surName + ", joiningDate=" + joiningDate + ", birthDate=" + birthDate + ", qualification=" + qualification
			+ ", address=" + address + ", contactNo=" + contactNo + ", designation=" + designation + ", role=" + role
			+ "]";
}


	

}*/
