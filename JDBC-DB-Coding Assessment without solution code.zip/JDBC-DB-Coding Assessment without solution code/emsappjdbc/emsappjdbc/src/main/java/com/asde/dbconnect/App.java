package com.asde.dbconnect;

import java.sql.SQLException;
import java.util.List;

import com.asde.dbconnect.dao.EmployeeDAO;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws SQLException
    {
   EmployeeDAO empdaoimpl = new EmployeeDAO(); // Employee e1=new
   List l = empdaoimpl.searchEmployeeByDesignation("Senior Associate");
   System.out.println(l);


    }
}
