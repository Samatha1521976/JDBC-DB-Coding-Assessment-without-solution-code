package com.asde.dbconnect.entities;


public class Skill {

}
