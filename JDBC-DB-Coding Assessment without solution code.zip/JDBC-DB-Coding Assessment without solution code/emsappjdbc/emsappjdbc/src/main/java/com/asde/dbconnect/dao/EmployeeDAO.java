package com.asde.dbconnect.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.asde.dbconnect.entities.Employee;
import com.asde.dbconnect.util.connection.DBConnectionManager;


public class EmployeeDAO implements IEmployeeDAO
{
	
	
	Connection connection=null; 
	DBConnectionManager d=null;
	//Connection c=null;
	//PreparedStatement ps=null;
	
 public EmployeeDAO() 
{
	 d=new DBConnectionManager();
}
	

	public List searchEmployee(Employee employee) throws SQLException {
		connection=d.getConnection();
			}
	
	
	public List searchEmployeeByDesignation(String des) throws SQLException {
		
		connection=d.getConnection();
			return data;
	}

}
